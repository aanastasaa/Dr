
import React, { useState } from 'react';

export const RSVPForm: React.FC = () => {
  const [submitted, setSubmitted] = useState(false);
  const [name, setName] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  if (submitted) {
    return (
      <div className="text-center p-4 space-y-4">
        <div className="text-3xl">💿</div>
        <p className="font-bold text-green-700">ТЫ В СПИСКЕ, {name.toUpperCase()}!</p>
        <p className="text-xs">Увидимся на танцполе. Не забудь жвачку Love Is...</p>
        <button 
          onClick={() => setSubmitted(false)}
          className="win95-border win95-button bg-[#c0c0c0] px-4 py-1 text-xs"
        >
          OK
        </button>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4 text-sm">
      <div className="space-y-1">
        <label className="block font-bold">Как тебя зовут?</label>
        <input 
          type="text" 
          required
          value={name}
          onChange={(e) => setName(e.target.value)}
          className="w-full win95-border-inset p-1 bg-white outline-none"
          placeholder="Напр. Дима"
        />
      </div>

      <div className="space-y-2">
        <label className="block font-bold">Будешь зажигать?</label>
        <div className="flex gap-4">
          <label className="flex items-center gap-1">
            <input type="radio" name="attending" defaultChecked /> Да!
          </label>
          <label className="flex items-center gap-1">
            <input type="radio" name="attending" /> Как бы нет...
          </label>
        </div>
      </div>

      <div className="space-y-1">
        <label className="block font-bold">Любимый трек из 90-х?</label>
        <input 
          type="text" 
          className="w-full win95-border-inset p-1 bg-white outline-none"
          placeholder="What is Love?"
        />
      </div>

      <div className="pt-2 flex justify-end">
        <button 
          type="submit"
          className="win95-border win95-button bg-[#c0c0c0] px-6 py-1 font-bold text-xs"
        >
          ОТПРАВИТЬ (ENTER)
        </button>
      </div>
    </form>
  );
};
