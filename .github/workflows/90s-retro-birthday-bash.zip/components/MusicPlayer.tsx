
import React, { useState, useEffect, useRef } from 'react';

export const MusicPlayer: React.FC = () => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [trackIndex, setTrackIndex] = useState(0);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const playlist = [
    { title: 'Haddaway - What is Love', url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3' },
    { title: 'E-Type - Russian Lullaby', url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3' },
    { title: 'Ace of Base - Happy Nation', url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3' }
  ];

  useEffect(() => {
    // Find the global audio element in App.tsx
    audioRef.current = document.querySelector('audio');
    if (audioRef.current) {
      setIsPlaying(!audioRef.current.paused);
    }
  }, []);

  const togglePlay = () => {
    if (!audioRef.current) return;
    if (isPlaying) {
      audioRef.current.pause();
    } else {
      audioRef.current.play();
    }
    setIsPlaying(!isPlaying);
  };

  const nextTrack = () => {
    const next = (trackIndex + 1) % playlist.length;
    setTrackIndex(next);
    if (audioRef.current) {
      audioRef.current.src = playlist[next].url;
      audioRef.current.play();
      setIsPlaying(true);
    }
  };

  return (
    <div className="w-[280px] bg-[#c0c0c0] p-1 win95-border-inset">
      <div className="bg-black p-2 space-y-2 rounded-sm border-2 border-gray-600">
        <div className="flex justify-between items-start">
          <div className="text-[9px] text-lime-500 font-mono tracking-tighter">
            00:42 / 03:59
          </div>
          <div className="text-[8px] text-lime-500 font-mono italic">
            WINAMP 2.0
          </div>
        </div>

        {/* Visualizer Mock */}
        <div className="flex items-end justify-center gap-[2px] h-10 border-b border-gray-800 pb-1">
          {[...Array(24)].map((_, i) => (
            <div 
              key={i} 
              className="bg-gradient-to-t from-green-500 to-lime-300 w-2" 
              style={{ 
                height: isPlaying ? `${Math.max(10, Math.random() * 100)}%` : '5%',
                transition: 'height 0.08s ease-in-out' 
              }} 
            />
          ))}
        </div>

        <div className="text-[10px] text-lime-400 font-mono truncate animate-marquee">
          {isPlaying ? `PLAYING: ${playlist[trackIndex].title}` : 'PAUSED - CLICK PLAY'}
        </div>
      </div>

      <div className="mt-2 grid grid-cols-5 gap-1">
        <button className="win95-border win95-button bg-[#c0c0c0] text-[9px] p-1 font-bold">⏮</button>
        <button 
          onClick={togglePlay}
          className="win95-border win95-button bg-[#c0c0c0] text-[10px] p-1 font-bold text-blue-900"
        >
          {isPlaying ? '⏸' : '▶'}
        </button>
        <button className="win95-border win95-button bg-[#c0c0c0] text-[9px] p-1 font-bold">⏹</button>
        <button 
          onClick={nextTrack}
          className="win95-border win95-button bg-[#c0c0c0] text-[9px] p-1 font-bold"
        >
          ⏭
        </button>
        <button className="win95-border win95-button bg-[#c0c0c0] text-[9px] p-1 font-bold">⏏</button>
      </div>

      <div className="mt-2 flex justify-between items-center px-1">
        <div className="flex gap-1 h-3">
          <div className="w-4 bg-gray-400 win95-border-inset" />
          <div className="w-12 bg-gray-400 win95-border-inset" />
        </div>
        <div className="text-[7px] text-gray-700 font-bold uppercase italic">
          High Fidelity
        </div>
      </div>
    </div>
  );
};
