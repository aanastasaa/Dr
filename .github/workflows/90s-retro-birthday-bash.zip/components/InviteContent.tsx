
import React from 'react';

export const InviteContent: React.FC = () => {
  return (
    <div className="space-y-6 max-w-lg">
      <div className="text-center relative">
        <h1 className="text-4xl font-black text-blue-900 italic pixel-font mb-2 glitch-text tracking-tighter">
          ЙОУ! ПАТИ НА ХАТЕ!
        </h1>
        <div className="relative inline-block">
          <img 
            src="https://images.unsplash.com/photo-1514525253344-a8135a43cf3e?auto=format&fit=crop&q=80&w=400" 
            alt="90s Party" 
            className="win95-border border-4 grayscale hover:grayscale-0 transition-all duration-500 cursor-crosshair"
          />
          <div className="absolute -top-4 -right-4 bg-yellow-400 text-black font-bold p-2 rotate-12 win95-border pixel-font text-xl">
            27 лет!
          </div>
        </div>
      </div>

      <div className="space-y-3 text-sm leading-relaxed win95-border-inset p-4 bg-gray-100">
        <p className="font-bold text-blue-800 text-lg underline decoration-pink-500">Привет, реальные пацаны и девчонки!</p>
        <p>
          Это не просто днюха, это <span className="text-pink-600 font-extrabold">ПОРТАЛ В 90-Е</span>! 
          Доставай свои лучшие шмотки, заправляй плеер и готовься отрываться так, будто завтра — дефолт!
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
        <div className="win95-border p-3 bg-yellow-50 relative overflow-hidden group">
          <div className="font-bold text-blue-800 underline mb-1">ГДЕ СХОДКА:</div>
          <div className="font-mono text-sm">
            рп Боброво<br/>
            ул. Лесная, д. 12, кв. 592
          </div>
          <div className="absolute -bottom-2 -right-2 text-4xl opacity-10 group-hover:opacity-30 transition-opacity">📍</div>
        </div>
        <div className="win95-border p-3 bg-cyan-50 relative overflow-hidden group">
          <div className="font-bold text-blue-800 underline mb-1">ВРЕМЯ X:</div>
          <div className="font-mono text-sm text-red-600 font-bold">
            2 Марта, 19:00<br/>
            (до последнего выжившего)
          </div>
          <div className="absolute -bottom-2 -right-2 text-4xl opacity-10 group-hover:opacity-30 transition-opacity">⏰</div>
        </div>
      </div>

      <div className="win95-border p-4 bg-indigo-900 text-white space-y-2">
        <div className="text-yellow-400 font-bold border-b border-yellow-400 pb-1 mb-2 flex justify-between items-center">
          <span>ДРЕСС-КОД: СТИЛЬ 90х</span>
          <span className="animate-pulse">!!!</span>
        </div>
        <ul className="text-[10px] space-y-1 list-disc list-inside font-mono">
          <li>Спортивки Adidas (три полоски — это база)</li>
          <li>Джинсы-варенки и оверсайз куртки</li>
          <li>Кислотные лосины и яркий макияж</li>
          <li>Огромные цепи, барсетки, начёсы</li>
          <li>Очки "как у кота Базилио"</li>
        </ul>
      </div>

      <div className="bg-black text-lime-400 p-3 text-[10px] pixel-font border-l-4 border-lime-400 animate-pulse">
        &gt; SYSTEM_STATUS: MAXIMUM_RADICAL<br/>
        &gt; BEER_CONSUMPTION: 100%<br/>
        &gt; NOSTALGIA_LEVEL: CRITICAL_MAX
      </div>
    </div>
  );
};
