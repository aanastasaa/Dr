
import React, { useState, useCallback, useRef } from 'react';
import { Taskbar } from './components/Taskbar';
import { Window } from './components/Window';
import { DesktopIcon } from './components/DesktopIcon';
import { InviteContent } from './components/InviteContent';
import { RSVPForm } from './components/RSVPForm';
import { AiAssistant } from './components/AiAssistant';
import { MusicPlayer } from './components/MusicPlayer';
import { BootScreen } from './components/BootScreen';
import { WindowState } from './types';

const App: React.FC = () => {
  const [isBooted, setIsBooted] = useState(false);
  const audioRef = useRef<HTMLAudioElement>(null);
  
  const [windows, setWindows] = useState<WindowState[]>([
    {
      id: 'invite',
      title: 'INVITATION.EXE',
      isOpen: true,
      isMinimized: false,
      zIndex: 10,
      content: <InviteContent />,
      icon: '✉️'
    },
    {
      id: 'rsvp',
      title: 'RSVP_FORM.BAT',
      isOpen: false,
      isMinimized: false,
      zIndex: 1,
      content: <RSVPForm />,
      icon: '📝'
    },
    {
      id: 'ai',
      title: '90s_CYBER_GENIUS.COM',
      isOpen: false,
      isMinimized: false,
      zIndex: 1,
      content: <AiAssistant />,
      icon: '🤖'
    },
    {
      id: 'music',
      title: 'WINAMP_LITE',
      isOpen: true,
      isMinimized: false,
      zIndex: 5,
      content: <MusicPlayer />,
      icon: '📻'
    }
  ]);

  const [maxZ, setMaxZ] = useState(10);

  const toggleWindow = useCallback((id: string) => {
    setWindows(prev => prev.map(w => {
      if (w.id === id) {
        const newState = !w.isOpen;
        const newZ = newState ? maxZ + 1 : w.zIndex;
        if (newState) setMaxZ(newZ);
        return { ...w, isOpen: newState, isMinimized: false, zIndex: newZ };
      }
      return w;
    }));
  }, [maxZ]);

  const focusWindow = useCallback((id: string) => {
    setWindows(prev => prev.map(w => {
      if (w.id === id) {
        const newZ = maxZ + 1;
        setMaxZ(newZ);
        return { ...w, zIndex: newZ, isMinimized: false };
      }
      return w;
    }));
  }, [maxZ]);

  const minimizeWindow = useCallback((id: string) => {
    setWindows(prev => prev.map(w => w.id === id ? { ...w, isMinimized: true } : w));
  }, []);

  const closeWindow = useCallback((id: string) => {
    setWindows(prev => prev.map(w => w.id === id ? { ...w, isOpen: false } : w));
  }, []);

  const handleBootComplete = () => {
    setIsBooted(true);
    // Try to play music after user interaction
    if (audioRef.current) {
      audioRef.current.play().catch(e => console.log("Autoplay blocked, user needs to click music player."));
    }
  };

  return (
    <>
      {!isBooted && <BootScreen onBootComplete={handleBootComplete} />}
      
      <div className={`relative w-screen h-screen overflow-hidden bg-[#008080] select-none transition-opacity duration-1000 ${isBooted ? 'opacity-100' : 'opacity-0'}`}>
        <audio ref={audioRef} loop src="https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3" />
        
        {/* Marquee Header */}
        <div className="fixed top-0 left-0 w-full z-50">
          <marquee scrollamount="8" className="bg-black text-lime-400 py-1">
            !!! ВНИМАНИЕ !!! ВЕЧЕРИНКА В СТИЛЕ 90-Х !!! БОБРОВО ЖДЕТ ТЕБЯ !!! ПРИХОДИ В КОСТЮМЕ !!! БУДЕТ КРУТО !!! ТАМАГОЧИ ПРИНОСИТЬ С СОБОЙ !!!
          </marquee>
        </div>

        {/* Desktop Icons */}
        <div className="pt-12 pl-4 grid grid-cols-1 gap-6 w-24">
          {windows.map(w => (
            <DesktopIcon 
              key={w.id} 
              title={w.title} 
              icon={w.icon || '📁'} 
              onDoubleClick={() => toggleWindow(w.id)} 
            />
          ))}
        </div>

        {/* Windows Layer */}
        {windows.filter(w => w.isOpen && !w.isMinimized).map(w => (
          <Window
            key={w.id}
            title={w.title}
            zIndex={w.zIndex}
            onClose={() => closeWindow(w.id)}
            onMinimize={() => minimizeWindow(w.id)}
            onFocus={() => focusWindow(w.id)}
          >
            {w.content}
          </Window>
        ))}

        {/* Taskbar */}
        <Taskbar 
          windows={windows} 
          onWindowClick={(id) => {
            const w = windows.find(win => win.id === id);
            if (w?.isMinimized || !w?.isOpen) {
              toggleWindow(id);
            } else {
              focusWindow(id);
            }
          }}
        />
      </div>
    </>
  );
};

export default App;
